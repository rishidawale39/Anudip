package dao;

import db.DBConnection;
import models.Bid;

import java.sql.*;

public class BidDAO {
    public boolean placeBid(Bid bid) {
        String sql = "INSERT INTO bids (auction_id, bidder_id, bid_amount) VALUES (?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, bid.getAuctionId());
            stmt.setInt(2, bid.getBidderId());
            stmt.setDouble(3, bid.getBidAmount());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error placing bid: " + e.getMessage());
            return false;
        }
    }
}
