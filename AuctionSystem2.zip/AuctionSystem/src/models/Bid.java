package models;

public class Bid {
    private int id;
    private int auctionId;
    private int bidderId;
    private double bidAmount;

    public Bid(int id, int auctionId, int bidderId, double bidAmount) {
        this.id = id;
        this.auctionId = auctionId;
        this.bidderId = bidderId;
        this.bidAmount = bidAmount;
    }

    public Bid(int auctionId, int bidderId, double bidAmount) {
        this.auctionId = auctionId;
        this.bidderId = bidderId;
        this.bidAmount = bidAmount;
    }

    public int getId() { return id; }
    public int getAuctionId() { return auctionId; }
    public int getBidderId() { return bidderId; }
    public double getBidAmount() { return bidAmount; }
}
