package models;

public class Auction {
    private int id;
    private String itemName;
    private double startingPrice;
    private int sellerId;

    public Auction(int id, String itemName, double startingPrice, int sellerId) {
        this.id = id;
        this.itemName = itemName;
        this.startingPrice = startingPrice;
        this.sellerId = sellerId;
    }

    public Auction(String itemName, double startingPrice, int sellerId) {
        this.itemName = itemName;
        this.startingPrice = startingPrice;
        this.sellerId = sellerId;
    }

    public int getId() { return id; }
    public String getItemName() { return itemName; }
    public double getStartingPrice() { return startingPrice; }
    public int getSellerId() { return sellerId; }
}
