import models.User;
import services.AuthService;
import services.SellerService;
import services.BuyerService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AuthService authService = new AuthService();
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to the Auction System");

        while (true) {
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    authService.register();
                    break;

                case 2:
                    User user = authService.login();
                    if (user != null) {
                        System.out.println("Login successful. Welcome " + user.getUsername() + "!");
                        if (user.getRole().equalsIgnoreCase("seller")) {
                            sellerMenu(user.getId());
                        } else if (user.getRole().equalsIgnoreCase("buyer")) {
                            buyerMenu(user.getId());
                        } else {
                            System.out.println("Unknown role: " + user.getRole());
                        }
                    } else {
                        System.out.println("Login failed.");
                    }
                    break;

                case 3:
                    System.out.println("Goodbye!");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void sellerMenu(int sellerId) {
        SellerService sellerService = new SellerService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Seller Menu ---");
            System.out.println("1. Create Auction");
            System.out.println("2. Logout");
            System.out.print("Choose option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    sellerService.createAuction(sellerId);
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void buyerMenu(int buyerId) {
        BuyerService buyerService = new BuyerService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Buyer Menu ---");
            System.out.println("1. View Auctions & Place Bid");
            System.out.println("2. Logout");
            System.out.print("Choose option: ");
            int choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    buyerService.viewAndBid(buyerId);
                    break;
                case 2:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
