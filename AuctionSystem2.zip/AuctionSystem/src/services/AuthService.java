package services;

import java.util.Scanner;

import dao.UserDAO;
import models.User;

public class AuthService {
    private final UserDAO userDAO = new UserDAO();
    Scanner sc = new Scanner(System.in);
    public void register() {
        System.out.println("\n--- Register ---");
        System.out.println("Enter Username : ");
        String username = sc.next();
        System.out.println("Enter Password : ");
        String password  = sc.next();
        System.out.println("Enter role (buyer/seller): ");
        String role = sc.next();

        User user = new User(username, password, role);
        boolean success = userDAO.insertUser(user);

        if (success) {
            System.out.println("Registration successful.");
        } else {
            System.out.println("Registration failed.");
        }
    }

    public User login() {
        System.out.println("\n--- Login ---");
        System.out.println("Username : ");
        String username = sc.next();
        System.out.println("Password :");
        String pass = sc.next();

        User user = userDAO.getUser(username, pass);

        if (user != null) {

            System.out.println("Welcome, " + user.getUsername() + "! Logged in as " + user.getRole());

        } else {
            System.out.println("Invalid credentials.");
        }

        return user;
    }
}
