package services;

import dao.AuctionDAO;
import models.Auction;

import java.util.Scanner;

public class SellerService {
    private final AuctionDAO auctionDAO = new AuctionDAO();
    private final Scanner sc = new Scanner(System.in);

    public void createAuction(int sellerId) {
        System.out.println("\n--- Create Auction ---");
        System.out.print("Item Name: ");
        String item = sc.nextLine();
        System.out.print("Starting Price: ");
        double price = sc.nextDouble();
        sc.nextLine(); // Consume newline

        Auction auction = new Auction(item, price, sellerId);
        boolean success = auctionDAO.createAuction(auction);

        if (success) {
            System.out.println("Auction created successfully!");
        } else {
            System.out.println("Failed to create auction.");
        }
    }
}
