package services;

import dao.AuctionDAO;
import dao.BidDAO;
import models.Auction;
import models.Bid;

import java.util.List;
import java.util.Scanner;

public class BuyerService {
    private final AuctionDAO auctionDAO = new AuctionDAO();
    private final BidDAO bidDAO = new BidDAO();
    private final Scanner sc = new Scanner(System.in);

    public void viewAndBid(int buyerId) {
        List<Auction> auctions = auctionDAO.getAllAuctions();

        if (auctions.isEmpty()) {
            System.out.println("No auctions available.");
            return;
        }

        System.out.println("\n--- Available Auctions ---");
        for (Auction auction : auctions) {
            System.out.println("ID: " + auction.getId() + ", Item: " + auction.getItemName() +
                    ", Price: " + auction.getStartingPrice());
        }

        System.out.print("Enter auction ID to bid on: ");
        int auctionId = sc.nextInt();
        System.out.print("Enter your bid amount: ");
        double bidAmount = sc.nextDouble();
        sc.nextLine(); // Consume newline

        Bid bid = new Bid(auctionId, buyerId, bidAmount);
        boolean success = bidDAO.placeBid(bid);

        if (success) {
            System.out.println("Bid placed successfully.");
        } else {
            System.out.println("Failed to place bid.");
        }
    }
}
